
const MyERC20 = artifacts.require("./MyERC20.sol");
const MyERC721 = artifacts.require("./MyERC721.sol");
const MyERC1155 = artifacts.require("./MyERC1155.sol");


var erc20_contract_address = "";
var erc721_contract_address = "";
var erc1155_contract_address = "";

var source = "besu_erc20"

module.exports = function (deployer) {

    deployer.deploy(MyERC20).then(function(){
      erc20_contract_address = MyERC20.address;
        return deployer.deploy(MyERC721).then(function(){
          erc721_contract_address = MyERC721.address;
          return deployer.deploy(MyERC1155).then(function(){
            erc1155_contract_address = MyERC1155.address;
            console.log("ERC20               ==> ", erc20_contract_address);
            console.log("ERC721              ==> ", erc721_contract_address);
            console.log("ERC1155             ==> ", erc1155_contract_address);
          });
        });
    }); 
};
