pragma solidity >=0.5.16;

import 'openzeppelin-solidity/contracts/token/ERC721/ERC721.sol'; 


contract MyERC721 is ERC721{ 
    constructor() ERC721("ERC721 token","SPA"){ 
      super._mint(msg.sender, 1);
    } 
}