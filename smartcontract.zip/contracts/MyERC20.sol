pragma solidity >=0.5.16;

import 'openzeppelin-solidity/contracts/token/ERC20/ERC20.sol'; 


contract MyERC20 is ERC20{ 
    uint public INITIAL_SUPPLY = 12000000000000; 
    constructor() ERC20("ERC20 token","MT"){ 
        _mint(msg.sender, INITIAL_SUPPLY);       
    } 
}

