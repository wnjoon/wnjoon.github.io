pragma solidity >=0.5.16;

import 'openzeppelin-solidity/contracts/token/ERC1155/ERC1155.sol'; 


contract MyERC1155 is ERC1155{ 
    constructor() ERC1155("ipfs://{cid}"){ 
      super._mint(msg.sender, 1, 1, "1");
    } 
}